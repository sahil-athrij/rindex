1.1 DCNM SAN:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
1) Upgrade DCNM to 11.5.
2) In case of Windows deployment, Follow the below steps:
(i) Stop DCNM services,
(ii) Perform Disk defragmentation,
(iii) Increase ES Heap Memory to 8GB, refer section 1.3,
(iii) Start DCNM services, make sure all the services are up and running.
3) Stop PM Collection.
4) Unzip elasticreindex_reindex.zip.
5) cd elasticreindex
6) Run “Command Prompt” as an Administrator in Windows. root/sysadmin for RHEL/OVA
7) Execute slowreindex.bat or ./slowreindex.sh from the command line
 Or direct log/output to txt file
# .\slowreindex.bat 2>&1 | tee -APPEND reindex_log.txt
8) Incase of federation use ./slowreindex.sh -i federation
9) By fault script will re-index the last 365days data, If you have any specific requirement, use 
-d 365 : Number of days of data to be retained


--------------------------------------------------------------------------------------------------------------------------------------------
1.2 DCNM LAN:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
1) Upgrade DCNM to 11.5.
2) Make sure all the services are up and running.
3) Unzip elasticreindex_reindex.zip.
4) cd elasticreindex
5) Screen
6) Execute ./slowreindex.sh from the command line
7) By fault script will re-index the last 365days data, If you have any specific requirement, use 
-d 365 : Number of days of data to be retained


----------------------------------------------------------------------------------------------------------------------------------------------
1.3 Please follow below steps to increase the ES heap memory on windows::::::::::::::::::::::::::::::::::::::::::::::::::::::
 
1. Stop ES service.
2. Update below data on jvm.options present at C:\Program Files\Cisco Systems\dcm\elasticsearch\config
 
# Xms represents the initial size of total heap space
# Xmx represents the maximum size of total heap space
 
-Xms8g
-Xmx8g
 
3. Open Cmd prompt run as administrator
4. cd C:\Program Files\Cisco Systems\dcm\elasticsearch\bin
5. execute:  elasticsearch-service.bat manager
6. it opens below popup, Please update for JavaOptions with required heap size on Java tab.
7. Also update for Initial memory pool & Maximam memory pool.
8. Restart the ES service.
